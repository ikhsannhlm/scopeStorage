package com.example.scopestorage;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int CAMERA_PERMISSION_REQUEST = 1;
    private ImageView imgCapturedImage;
    private Uri imageUri; // Deklarasikan imageUri sebagai variabel anggota kelas

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnTakePicture = findViewById(R.id.btnTakePicture);
        imgCapturedImage = findViewById(R.id.imgCapturedImage);

        btnTakePicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkCameraPermission();
            }
        });
    }

    private void checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
        } else {
            takePicture();
        }
    }

    private void takePicture() {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.TITLE, "My Picture");
            values.put(MediaStore.Images.Media.DESCRIPTION, "Image captured by Scope Storage Sample App");
            imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values); // Menggunakan imageUri yang telah dideklarasikan

            if (imageUri != null) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
                startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
            } else {
                // Penanganan jika gagal membuat URI penyimpanan
                // Misalnya, Anda bisa menampilkan pesan kesalahan kepada pengguna.
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Penanganan jika terjadi kesalahan lain saat mengambil gambar.
            // Misalnya, Anda bisa menampilkan pesan kesalahan kepada pengguna.
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            // Gambar telah diambil dan disimpan.
            imgCapturedImage.setVisibility(View.VISIBLE);
            imgCapturedImage.setImageURI(imageUri);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                takePicture();
            } else {
                // Izin kamera ditolak, Anda dapat memberikan pesan kepada pengguna atau melakukan tindakan lainnya.
            }
        }
    }
}
